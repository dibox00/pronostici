from flask import Flask, render_template, request
import requests
from dotenv import load_dotenv
import os

load_dotenv()

app = Flask(__name__)
API_KEY = os.getenv("OPENROUTER_API_KEY")
API_URL = "https://openrouter.ai/api/v1/chat/completions"
MODEL = "deepseek/deepseek-r1-distill-llama-70b:free"

def query_ai(prompt):
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": MODEL,
        "messages": [{"role": "user", "content": prompt}]
    }
    response = requests.post(API_URL, headers=headers, json=payload)
    response.raise_for_status()
    return response.json()["choices"][0]["message"]["content"]

@app.route("/", methods=["GET", "POST"])
def index():
    matches, multipla, singola = [], "", ""
    if request.method == "POST":
        sport = request.form["sport"]
        prompt_matches = f"Dammi un elenco realistico e aggiornato di partite di {sport} che si giocheranno nei prossimi 7 giorni. Specifica data, squadre o giocatori, e il torneo."
        matches_response = query_ai(prompt_matches)
        matches = matches_response.strip().split("\n")

        prompt_bets = f"Analizza le seguenti partite di {sport} e genera:
1. Una schedina multipla con almeno 3 partite, ognuna con analisi e percentuale di sicurezza.
2. Una schedina singola con la partita più sicura, con motivazione dettagliata professionale.
Ecco le partite:
" + "\n".join(matches)
        bets_response = query_ai(prompt_bets)

        if "Schedina Multipla" in bets_response:
            parts = bets_response.split("Schedina Singola")
            multipla = parts[0].replace("Schedina Multipla:", "").strip()
            singola = "Schedina Singola" + parts[1].strip()
        else:
            multipla = bets_response.strip()

    return render_template("index.html", matches=matches, multipla=multipla, singola=singola)

if __name__ == "__main__":
    app.run(debug=True)
