
import os
import requests
from flask import Flask, render_template, request
from dotenv import load_dotenv

load_dotenv()
API_KEY = os.getenv("OPENROUTER_API_KEY")

app = Flask(__name__)

def query_ai(prompt):
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    data = {
        "model": "deepseek/deepseek-r1-distill-llama-70b:free",
        "messages": [
            {"role": "system", "content": "Sei un esperto tipster di calcio e tennis. Fornisci analisi realistiche e professionali."},
            {"role": "user", "content": prompt}
        ]
    }
    response = requests.post("https://openrouter.ai/api/v1/chat/completions", headers=headers, json=data)
    return response.json()["choices"][0]["message"]["content"]

@app.route("/", methods=["GET", "POST"])
def index():
    predictions = ""
    sport = ""
    if request.method == "POST":
        sport = request.form.get("sport")
        match_prompt = f"Elenca le partite di {sport.lower()} in programma da oggi fino a 7 giorni da oggi, indicando data, torneo e squadre/giocatori."
        match_list = query_ai(match_prompt)
        
        bet_prompt = f"Basandoti su queste partite:
{match_list}

Crea:
1. Una schedina multipla con almeno 3 partite, ognuna con analisi e percentuale di vincita.
2. Una schedina singola con la partita più sicura, motivata professionalmente."
        predictions = query_ai(bet_prompt)

        return render_template("index.html", sport=sport, matches=match_list, predictions=predictions)
    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0')
