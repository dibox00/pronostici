import os
import openai
import requests
from flask import Flask, render_template, request
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)

API_KEY = os.getenv("OPENROUTER_API_KEY")
API_URL = "https://openrouter.ai/api/v1/chat/completions"
MODEL = "deepseek/deepseek-r1-distill-llama-70b:free"

headers = {
    "Authorization": f"Bearer {API_KEY}",
    "Content-Type": "application/json"
}

def ask_ai(prompt):
    payload = {
        "model": MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.7
    }
    response = requests.post(API_URL, json=payload, headers=headers)
    data = response.json()
    return data["choices"][0]["message"]["content"]

@app.route("/", methods=["GET", "POST"])
def index():
    results = None
    if request.method == "POST":
        sport = request.form.get("sport")
        prompt_matches = f"Genera un elenco realistico e aggiornato di partite future di {sport.lower()} tra oggi e 7 giorni. Includi data, squadre/giocatori e torneo/competizione."
        matches = ask_ai(prompt_matches)

        prompt_bets = f"Su queste partite di {sport}:
{matches}

Genera:
1. Una schedina multipla con almeno 3 partite, ognuna con analisi professionale e percentuale di successo.
2. Una schedina singola con la partita più sicura, motivata in modo professionale."
        predictions = ask_ai(prompt_bets)

        results = {"matches": matches, "predictions": predictions, "sport": sport}
    return render_template("index.html", results=results)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=81, debug=True)