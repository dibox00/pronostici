import os
from flask import Flask, render_template, request
import requests
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)

API_KEY = os.getenv("OPENROUTER_API_KEY")
API_URL = "https://openrouter.ai/api/v1/chat/completions"
MODEL = "deepseek/deepseek-r1-distill-llama-70b:free"

def call_ai(prompt):
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    data = {
        "model": MODEL,
        "messages": [
            {"role": "user", "content": prompt}
        ]
    }
    response = requests.post(API_URL, json=data, headers=headers)
    result = response.json()
    return result['choices'][0]['message']['content']

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        sport = request.form.get("sport")

        match_prompt = (
            f"Fornisci un elenco realistico di partite future di {sport}, dal giorno di oggi fino ai prossimi 7 giorni. "
            f"Indica data, squadre (per il calcio) o giocatori (per il tennis), e il torneo/campionato."
        )
        match_list = call_ai(match_prompt)

        bet_prompt = (
            f"Basandoti su queste partite di {sport} tra oggi e 7 giorni:\n{match_list}\n"
            f"Crea:\n1. Una schedina multipla con almeno 3 partite, ognuna con analisi e percentuale di vittoria.\n"
            f"2. Una schedina singola con la partita più sicura, con motivazione dettagliata e professionale."
        )
        bet_slip = call_ai(bet_prompt)

        return render_template("index.html", match_list=match_list, bet_slip=bet_slip, selected_sport=sport)

    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)